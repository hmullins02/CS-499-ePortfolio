package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AtomicMassCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Load element data from JSON file
        HashMap<String, Double> elements = loadElementsFromJson("elements.json");

        if (elements == null) {
            System.out.println("Failed to load elements data.");
            return;
        }

        // Introduction message to explain the program to the user
        System.out.println("Hello, I'm here to tell you the atomic mass of elements. Go ahead and add together up to 20 elements and I'll tell you the total atomic mass.");
        System.out.println("Please use the abbreviated version of the elements, and keep the number of each element under 20. You can exit at any time by typing 'exit'.");
        System.out.println("Click enter after typing your answer.\n");

        // Prompt the user to enter the number of elements they want to add
        System.out.println("How many elements do you want to add? (Max 20) Enter 'exit' to quit.");

        int numElements = 0;
        while (true) {
            String input = scanner.nextLine().trim().toLowerCase();

            // Check if the user wants to exit
            if ("exit".equals(input)) {
                System.out.println("Exiting...");
                scanner.close();
                return;
            }

            try {
                // Convert the user input to an integer
                numElements = Integer.parseInt(input);

                // Check if the input is within the allowed range
                if (numElements > 20 || numElements < 1) {
                    System.out.println("Invalid number of elements. Please enter a number between 1 and 20 or 'exit' to quit.");
                } else {
                    break; // Exit the loop if input is valid
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number or 'exit' to quit.");
            }
        }

        // HashMap to store the counts of each element
        HashMap<String, Integer> moleculeCounts = new HashMap<>();

        // Loop to prompt the user to enter each element and its count
        for (int i = 0; i < numElements; i++) {
            System.out.println("Enter element " + (i + 1) + " (e.g., H, He, Li):");
            String element = scanner.nextLine().trim().toLowerCase();

            // Check if the user wants to exit
            if ("exit".equals(element)) {
                System.out.println("Exiting...");
                scanner.close();
                return;
            }

            if (elements.containsKey(element)) {
                int numMolecules = 0;
                while (true) {
                    // Prompt the user to enter the number of molecules for the current element
                    System.out.println("Enter the number of molecules for " + element + ":");
                    String moleculeInput = scanner.nextLine().trim().toLowerCase();

                    // Check if the user wants to exit
                    if ("exit".equals(moleculeInput)) {
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    }

                    try {
                        // Convert the user input to an integer
                        numMolecules = Integer.parseInt(moleculeInput);

                        // Check if the input is within the allowed range
                        if (numMolecules < 1 || numMolecules > 20) {
                            System.out.println("Invalid number of molecules. Please enter a number between 1 and 20 or 'exit' to quit.");
                        } else {
                            break; // Exit the loop if input is valid
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid number or 'exit' to quit."); // If invalid, prompt again
                    }
                }

                // Update the count of the current element in the HashMap
                moleculeCounts.put(element, moleculeCounts.getOrDefault(element, 0) + numMolecules);
            } else {
                System.out.println("Invalid element. Please enter a valid element symbol or 'exit' to quit.");
                i--;  // Decrement i to ask for the same element again
            }
        }

        // Calculate the total atomic mass based on the entered elements and their counts
        double totalMass = 0.0;
        for (String element : moleculeCounts.keySet()) {
            int numMolecules = moleculeCounts.get(element);
            totalMass += (elements.get(element) * numMolecules);
        }

        // Display the total atomic mass to the user
        System.out.println("--------------------------------------------");
        System.out.println("The total atomic mass is: " + String.format("%.3f", totalMass));
        System.out.println("--------------------------------------------");

        scanner.close();
    }

    // Function to load elements data from a JSON file
    private static HashMap<String, Double> loadElementsFromJson(String filename) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            // Read JSON file and convert it to a HashMap
            return mapper.readValue(new File(filename), HashMap.class);
        } catch (IOException e) {
            System.out.println("Error reading JSON file: " + e.getMessage());
            return null;
        }
    }
}
