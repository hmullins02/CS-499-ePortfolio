package com.example.hayleymullinsmodule3assignment;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.io.IOException;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
        private EditText editElement; // Input field for element symbol
        private EditText editCount;   // Input field for element count
        private EditText editComment; // Input field for comment
        private TextView resultView;  // TextView to display total atomic mass
        private ArrayList<String> elementsList = new ArrayList<>(); // List to keep track of added elements
        private double totalMass = 0.0; // Variable to store total atomic mass
        private HashMap<String, Double> elements = new HashMap<>(); // HashMap to store element symbols and their atomic masses
        private AtomicMassDatabaseHelper dbHelper; // Database helper for managing calculations

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                // Initialize views
                editElement = findViewById(R.id.editElement);
                editCount = findViewById(R.id.editCount);
                editComment = findViewById(R.id.editComment);
                resultView = findViewById(R.id.resultView);

                // Initialize database helper
                dbHelper = new AtomicMassDatabaseHelper(this);

                // Populate elements HashMap with data from JSON file
                try {
                        populateElements();
                } catch (IOException e) {
                        Toast.makeText(this, "Error loading elements", Toast.LENGTH_SHORT).show();
                }
        }

        // Method to read elements data from a JSON file and populate the elements HashMap
        private void populateElements() throws IOException {
                InputStream is = getAssets().open("elements.json");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                String json = new String(buffer, "UTF-8");
                try {
                        JSONObject jsonObject = new JSONObject(json);
                        JSONArray elementsArray = jsonObject.getJSONArray("elements");
                        for (int i = 0; i < elementsArray.length(); i++) {
                                JSONObject element = elementsArray.getJSONObject(i);
                                String symbol = element.getString("symbol").toLowerCase();
                                double atomicMass = element.getDouble("atomic_mass");
                                elements.put(symbol, atomicMass);
                        }
                } catch (Exception e) {
                        e.printStackTrace();
                }
        }

        // Method to handle "Add Element" button click
        public void onAddElementClick(View view) {
                String element = editElement.getText().toString().trim().toLowerCase();
                int count;
                try {
                        count = Integer.parseInt(editCount.getText().toString().trim());
                } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter a valid count", Toast.LENGTH_SHORT).show();
                        return;
                }

                // Check if the entered element is valid and update total mass
                if (elements.containsKey(element)) {
                        double mass = elements.get(element) * count;
                        totalMass += mass;
                        elementsList.add(element + count);
                        resultView.setText(String.format("Total Mass: %.3f", totalMass));
                        // Clear the input fields after adding the element
                        editElement.setText("");
                        editCount.setText("");
                } else {
                        Toast.makeText(this, "Element not found", Toast.LENGTH_SHORT).show();
                }
        }

        // Method to handle "Save" button click
        public void onSaveClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(AtomicMassDatabaseHelper.COLUMN_DATE, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
                values.put(AtomicMassDatabaseHelper.COLUMN_RESULT, totalMass);
                values.put(AtomicMassDatabaseHelper.COLUMN_FAVORITE, 0);
                values.put(AtomicMassDatabaseHelper.COLUMN_COMMENT, editComment.getText().toString());
                values.put(AtomicMassDatabaseHelper.COLUMN_ELEMENTS, String.join(", ", elementsList));  // Save elements list as string

                long newRowId = db.insert(AtomicMassDatabaseHelper.TABLE_CALCULATIONS, null, values);

                if (newRowId != -1) {
                        Toast.makeText(this, "Calculation saved", Toast.LENGTH_SHORT).show();
                        // Clear inputs after saving
                        editElement.setText("");
                        editCount.setText("");
                        editComment.setText("");
                        resultView.setText("Total Mass: 0.0");
                        totalMass = 0.0;
                        elementsList.clear();
                } else {
                        Toast.makeText(this, "Error saving calculation", Toast.LENGTH_SHORT).show();
                }
        }

        // Method to handle "Show Calculations" button click
        public void onShowCalculationsClick(View view) {
                Intent intent = new Intent(this, DisplayCalculationsActivity.class);
                startActivity(intent);
        }

        // Method to handle "Clear Database" button click
        public void onClearDatabaseClick(View view) {
                dbHelper.clearDatabase();
                Toast.makeText(this, "Database cleared", Toast.LENGTH_SHORT).show();
        }
}
