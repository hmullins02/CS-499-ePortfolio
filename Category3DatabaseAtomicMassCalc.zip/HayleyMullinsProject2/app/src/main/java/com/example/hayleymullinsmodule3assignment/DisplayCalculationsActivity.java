package com.example.hayleymullinsmodule3assignment;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayCalculationsActivity extends AppCompatActivity {
    // UI component to hold calculation views
    private LinearLayout calculationsContainer;
    // Database helper to manage SQLite database
    private AtomicMassDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_calculations);

        // Initialize UI component
        calculationsContainer = findViewById(R.id.calculationsContainer);
        // Initialize database helper
        dbHelper = new AtomicMassDatabaseHelper(this);

        // Display all calculations by default
        displayCalculations(null);
    }

    /**
     * Displays calculations from the database in the UI.
     * @param orderBy The column to order the results by, or null for default order.
     */
    private void displayCalculations(String orderBy) {
        // Clear any existing views in the container
        calculationsContainer.removeAllViews();
        // Get readable database
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Columns to retrieve
        String[] projection = {
                AtomicMassDatabaseHelper.COLUMN_ID,
                AtomicMassDatabaseHelper.COLUMN_DATE,
                AtomicMassDatabaseHelper.COLUMN_RESULT,
                AtomicMassDatabaseHelper.COLUMN_FAVORITE,
                AtomicMassDatabaseHelper.COLUMN_COMMENT,
                AtomicMassDatabaseHelper.COLUMN_ELEMENTS
        };

        // Query the database
        Cursor cursor = db.query(
                AtomicMassDatabaseHelper.TABLE_CALCULATIONS,
                projection,
                null,
                null,
                null,
                null,
                orderBy
        );

        // Iterate through the results and add them to the UI
        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_DATE));
            double result = cursor.getDouble(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_RESULT));
            int favorite = cursor.getInt(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_FAVORITE));
            String comment = cursor.getString(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_COMMENT));
            String elements = cursor.getString(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_ELEMENTS));

            // Inflate a new view for this calculation
            View calculationView = getLayoutInflater().inflate(R.layout.calculation_item, null);
            TextView textViewElements = calculationView.findViewById(R.id.textViewElements);
            TextView textViewDate = calculationView.findViewById(R.id.textViewDate);
            TextView textViewResult = calculationView.findViewById(R.id.textViewResult);
            TextView textViewComment = calculationView.findViewById(R.id.textViewComment);
            CheckBox checkBoxFavorite = calculationView.findViewById(R.id.checkBoxFavorite);

            // Set the data in the view
            textViewElements.setText("Elements: " + elements);
            textViewDate.setText("Date: " + date);
            textViewResult.setText("Total Atomic Mass: " + result);
            textViewComment.setText("Comment: " + comment);
            checkBoxFavorite.setChecked(favorite == 1);

            // Handle favorite checkbox click
            checkBoxFavorite.setOnClickListener(v -> {
                ContentValues values = new ContentValues();
                values.put(AtomicMassDatabaseHelper.COLUMN_FAVORITE, checkBoxFavorite.isChecked() ? 1 : 0);
                db.update(AtomicMassDatabaseHelper.TABLE_CALCULATIONS, values, AtomicMassDatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
            });

            // Add the view to the container
            calculationsContainer.addView(calculationView);
        }
        // Close the cursor
        cursor.close();
    }

    /**
     * Handles the click event for sorting calculations in ascending order by result.
     * @param view The view that was clicked.
     */
    public void onSortAscendingClick(View view) {
        displayCalculations(AtomicMassDatabaseHelper.COLUMN_RESULT + " ASC");
    }

    /**
     * Handles the click event for sorting calculations in descending order by result.
     * @param view The view that was clicked.
     */
    public void onSortDescendingClick(View view) {
        displayCalculations(AtomicMassDatabaseHelper.COLUMN_RESULT + " DESC");
    }

    /**
     * Handles the click event for showing only favorite calculations.
     * @param view The view that was clicked.
     */
    public void onShowFavoritesClick(View view) {
        // Get readable database
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Columns to retrieve
        String[] projection = {
                AtomicMassDatabaseHelper.COLUMN_ID,
                AtomicMassDatabaseHelper.COLUMN_DATE,
                AtomicMassDatabaseHelper.COLUMN_RESULT,
                AtomicMassDatabaseHelper.COLUMN_FAVORITE,
                AtomicMassDatabaseHelper.COLUMN_COMMENT,
                AtomicMassDatabaseHelper.COLUMN_ELEMENTS
        };

        // Selection criteria
        String selection = AtomicMassDatabaseHelper.COLUMN_FAVORITE + " = ?";
        String[] selectionArgs = {"1"};

        // Query the database for favorite calculations
        Cursor cursor = db.query(
                AtomicMassDatabaseHelper.TABLE_CALCULATIONS,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        // Clear any existing views in the container
        calculationsContainer.removeAllViews();

        // Iterate through the results and add them to the UI
        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_DATE));
            double result = cursor.getDouble(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_RESULT));
            int favorite = cursor.getInt(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_FAVORITE));
            String comment = cursor.getString(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_COMMENT));
            String elements = cursor.getString(cursor.getColumnIndexOrThrow(AtomicMassDatabaseHelper.COLUMN_ELEMENTS));

            // Inflate a new view for this calculation
            View calculationView = getLayoutInflater().inflate(R.layout.calculation_item, null);
            TextView textViewElements = calculationView.findViewById(R.id.textViewElements);
            TextView textViewDate = calculationView.findViewById(R.id.textViewDate);
            TextView textViewResult = calculationView.findViewById(R.id.textViewResult);
            TextView textViewComment = calculationView.findViewById(R.id.textViewComment);
            CheckBox checkBoxFavorite = calculationView.findViewById(R.id.checkBoxFavorite);

            // Set the data in the view
            textViewElements.setText("Elements: " + elements);
            textViewDate.setText("Date: " + date);
            textViewResult.setText("Total Mass: " + result);
            textViewComment.setText("Comment: " + comment);
            checkBoxFavorite.setChecked(favorite == 1);

            // Handle favorite checkbox click
            checkBoxFavorite.setOnClickListener(v -> {
                ContentValues values = new ContentValues();
                values.put(AtomicMassDatabaseHelper.COLUMN_FAVORITE, checkBoxFavorite.isChecked() ? 1 : 0);
                db.update(AtomicMassDatabaseHelper.TABLE_CALCULATIONS, values, AtomicMassDatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
            });

            // Add the view to the container
            calculationsContainer.addView(calculationView);
        }
        // Close the cursor
        cursor.close();
    }

    /**
     * Handles the click event for going back to the main activity.
     * @param view The view that was clicked.
     */
    public void onBackToMainClick(View view) {
        finish();
    }
}
